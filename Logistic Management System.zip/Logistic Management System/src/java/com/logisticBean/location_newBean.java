/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.logisticBean;

import com.Dao.connDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHUBHAM
 */
public class location_newBean {

    private String locationId;
    private String shippingId;
    private String from;
    private String driverId;
    private String vehicleId;
    private String customerId;
    private String to;
    private String recent;
    private String date;
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    
    public String getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(String vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRecent() {
        return recent;
    }

    public void setRecent(String recent) {
        this.recent = recent;
    }

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    public String getShippingId() {
        return shippingId;
    }

    public void setShippingId(String shippingId) {
        this.shippingId = shippingId;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public boolean addLocation() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String query = "insert into location_new(shippingid, location,locationdate) values(?,?,?)";

        Date d = new Date();
        date = new SimpleDateFormat("dd-MMM-yyyy").format(d);
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, shippingId);
            ps.setString(2, recent);
            ps.setString(3, date);

            int count = ps.executeUpdate();
            if (count > 0) {
                setStatusDispatched();
                flag = true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(location_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return flag;
    }

    public boolean updateLocation() {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String query = "update location_new set location=?,locationdate=? where shippingid=? and locationid=?";
        Date d = new Date();
        date = new SimpleDateFormat("dd-MMM-yyyy").format(d);
        
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, recent);
            ps.setString(2, date);
            ps.setString(3, shippingId);
            ps.setString(4, locationId);
            int count = ps.executeUpdate();
            if (count > 0) {
                flag = true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return flag;

    }

    public int setStatusDispatched() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update goodsreceipt_new set status = ? where orderno =(select orderno from vehiclehire_new v, location_new l where  v.shippingid =l.shippingid and l.shippingid=?) ";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, "dispatched");
        ps.setString(2, shippingId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }
    public int setStatusCompleted() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update goodsreceipt_new set status = ? where orderno =(select orderno from vehiclehire_new v, location_new l where  v.shippingid =l.shippingid and l.shippingid=?) ";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, "delivered");
        ps.setString(2, shippingId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public ArrayList showAll() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from location_new where shippingid=(select shippingid from vehiclehire_new v,goodsreceipt_new g,driver_new d where v.driverid=? and v.driverid=d.driverid and d.status='assigned' and g.orderno=v.orderno and g.status='dispatched')";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1, driverId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                location_newBean location = new location_newBean();
                location.setLocationId(rs.getString("locationid"));
                location.setShippingId(rs.getString("shippingid"));
                location.setRecent(rs.getString("location"));
                date = rs.getString("locationdate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(date);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                date = sdf.format(d);

                location.setDate(date);
                data.add(location);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(location_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public boolean search() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from location_new where locationid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, locationId);
        
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            shippingId = rs.getString("shippingid");
            locationId = rs.getString("locationid");
            recent = rs.getString("location");
            date = rs.getString("locationdate");
            Date d=new SimpleDateFormat("yyyy-MM-dd").parse(date);
            date= new SimpleDateFormat("dd-MMM-yyyy").format(d);
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public boolean insert() throws ParseException, Exception {
        connDao con = new connDao();
        Connection connection = con.getConnection();

        String query = "insert into location_modify(locationid,shippingid, location, locationdate) values(?,?,?,?)";
        try {
            
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, locationId);
            ps.setString(2, shippingId);
            ps.setString(3, recent);
            ps.setString(4, date);

            int count = ps.executeUpdate();
            if (count > 0) {
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public boolean search1() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select g.*,l.*,v.vehicleid as vehicleid,v.driverid as driverid,g.status as status from location_new l, vehiclehire_new v, goodsreceipt_new g where l.locationid=? and l.shippingid=v.shippingid and v.orderno=g.orderno and g.status='dispatched'";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, locationId);
        
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            shippingId = rs.getString("shippingid");
            locationId = rs.getString("locationid");
            recent = rs.getString("location");
            date = rs.getString("locationdate");
            Date d=new SimpleDateFormat("yyyy-MM-dd").parse(date);
            date= new SimpleDateFormat("dd-MMM-yyyy").format(d);
            from=rs.getString("sourcecityid");
            to=rs.getString("destinationcityid");
            driverId=rs.getString("driverid");
            status=rs.getString("status");
            vehicleId=rs.getString("vehicleid");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }
    
     public boolean searchShippingId() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select g.*,l.*,v.vehicleid as vehicleid,v.driverid as driverid,g.status as status from location_new l, vehiclehire_new v, goodsreceipt_new g where l.shippingid=? and l.shippingid=v.shippingid and v.orderno=g.orderno and g.status='dispatched'";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, shippingId);
        
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            shippingId = rs.getString("shippingid");
            locationId = rs.getString("locationid");
            recent = rs.getString("location");
            date = rs.getString("locationdate");
            Date d=new SimpleDateFormat("yyyy-MM-dd").parse(date);
            date= new SimpleDateFormat("dd-MMM-yyyy").format(d);
            from=rs.getString("sourcecityid");
            to=rs.getString("destinationcityid");
            driverId=rs.getString("driverid");
            status=rs.getString("status");
            vehicleId=rs.getString("vehicleid");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }
    
    public ArrayList showAllModify() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from location_modify where locationid=?";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1,locationId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                location_newBean location = new location_newBean();
                location.setLocationId(rs.getString("locationid"));
                location.setShippingId(rs.getString("shippingid"));
                location.setRecent(rs.getString("location"));
                date = rs.getString("locationdate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(date);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                date = sdf.format(d);

                location.setDate(date);
                data.add(location);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(vehicleHire_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public ArrayList showAllCompleted() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from location_new where shippingid=(select shippingid from vehiclehire_new v,goodsreceipt_new g,driver_new d where v.driverid=? and v.driverid=d.driverid and g.orderno=v.orderno and (g.status='delivered' or g.status='invoice'))";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1, driverId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                location_newBean location = new location_newBean();
                location.setLocationId(rs.getString("locationid"));
                location.setShippingId(rs.getString("shippingid"));
                location.setRecent(rs.getString("location"));
                date = rs.getString("locationdate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(date);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                date = sdf.format(d);

                location.setDate(date);
                data.add(location);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(location_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public ArrayList showAllTrack() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select l.*,status,sourcecityid,destinationcityid from location_new l,vehiclehire_new v,goodsreceipt_new g,customer_new c where c.firmid=? and v.shippingid=l.shippingid and g.firmid=c.firmid and g.orderno=v.orderno and (g.status='dispatched' or g.status='delivered' or g.status='invoice') ";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1, customerId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                location_newBean location = new location_newBean();
                location.setLocationId(rs.getString("locationid"));
                location.setShippingId(rs.getString("shippingid"));
                location.setFrom(rs.getString("sourcecityid"));
                location.setTo(rs.getString("destinationcityid"));
                date = rs.getString("locationdate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(date);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                date = sdf.format(d);
                status=rs.getString("status");
               
                location.setDate(date);
                location.setStatus(status);
                data.add(location);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(location_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }
}
