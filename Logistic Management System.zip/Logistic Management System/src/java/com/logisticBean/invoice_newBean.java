/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.logisticBean;

import com.Dao.connDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHUBHAM
 */
public class invoice_newBean {

    private String invoiceNo;
    private String shippingId;
    private String invoiceDate;
    private String onRoadTax;
    private String GST;
    private String paid;
    private String totalDue;
    private String totalAmount;
    private String status;
    private String paymentDate;
    private String email;
    

    public String getInvoiceNo() {
        return invoiceNo;
    }

    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    public String getShippingId() {
        return shippingId;
    }

    public void setShippingId(String shippingId) {
        this.shippingId = shippingId;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getOnRoadTax() {
        return onRoadTax;
    }

    public void setOnRoadTax(String onRoadTax) {
        this.onRoadTax = onRoadTax;
    }

    public String getGST() {
        return GST;
    }

    public void setGST(String GST) {
        this.GST = GST;
    }

    public String getPaid() {
        return paid;
    }

    public void setPaid(String paid) {
        this.paid = paid;
    }

    public String getTotalDue() {
        return totalDue;
    }

    public void setTotalDue(String totalDue) {
        this.totalDue = totalDue;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    

    public boolean addInvoice() throws ParseException, Exception {
        connDao con = new connDao();
        Connection connection = con.getConnection();

        String query = "insert into invoice_new(shippingid, invoicedate, onroadtax, gst, total, paid, totaldue, status,paymentDate) values(?,?,?,?,?,?,?,?,?)";
        Date d = new Date();

        invoiceDate = new SimpleDateFormat("dd-MMM-yyyy").format(d);
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, shippingId);
            ps.setString(2, invoiceDate);
            ps.setString(3, onRoadTax);
            ps.setString(4, GST);
            ps.setString(5, totalAmount);
            ps.setString(6, paid);
            ps.setString(7, totalDue);
            int due = Integer.parseInt(totalDue);
            if (due > 0) {
                ps.setString(8, "due");
            } else if (due < 0) {
                return false;
            } else {
                ps.setString(8, "paid");
            }
            if (paid != null) {
                Date d1 = new Date();
                paymentDate = new SimpleDateFormat("dd-MMM-yyyy").format(d1);
            }
            ps.setString(9, paymentDate);
            int count = ps.executeUpdate();
            if (count > 0) {

                setStatusInvoice();
                return true;

            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public int setStatusInvoice() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update goodsreceipt_new set status = ? where orderno =(select orderno from vehiclehire_new v, invoice_new l where  v.shippingid =l.shippingid and l.shippingid=?) ";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, "invoice");
        ps.setString(2, shippingId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public ArrayList showAll() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from invoice_new";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                invoice_newBean invoice = new invoice_newBean();
                invoice.setInvoiceNo(rs.getString("invoiceno"));
                invoice.setShippingId(rs.getString("shippingid"));
                invoice.setStatus(rs.getString("status"));
                invoice.setTotalDue(rs.getString("totaldue"));
                invoiceDate = rs.getString("invoicedate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(invoiceDate);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                invoiceDate = sdf.format(d);
                invoice.setInvoiceDate(invoiceDate);

                data.add(invoice);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(invoice_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public ArrayList showRecentPayment() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from invoice_new where invoiceno=?";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1, invoiceNo);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                invoice_newBean invoice = new invoice_newBean();
                invoice.setInvoiceNo(rs.getString("invoiceno"));
                invoice.setTotalAmount(rs.getString("total"));
                invoice.setShippingId(rs.getString("shippingid"));
                paid = rs.getString("paid");
                if (paid == null) {
                    paid = "-";
                }
                invoice.setPaid(paid);
                invoice.setTotalDue(rs.getString("totaldue"));

                invoiceDate = rs.getString("invoicedate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(invoiceDate);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                invoiceDate = sdf.format(d);
                invoice.setInvoiceDate(invoiceDate);

                paymentDate = rs.getString("paymentdate");
                if (paymentDate != null) {
                    d = new SimpleDateFormat("yyyy-MM-dd").parse(paymentDate);
                    sdf = new SimpleDateFormat("dd-MMM-yyyy");
                    paymentDate = sdf.format(d);
                } else {
                    paymentDate = "-";
                }
                invoice.setPaymentDate(paymentDate);

                data.add(invoice);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(invoice_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public ArrayList showAllPayment() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from invoice_modify where invoiceno=?";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1, invoiceNo);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                invoice_newBean invoice = new invoice_newBean();
                invoice.setInvoiceNo(rs.getString("invoiceno"));
                invoice.setTotalAmount(rs.getString("total"));
                invoice.setShippingId(rs.getString("shippingid"));
                paid = rs.getString("paid");
                if (paid == null) {
                    paid = "-";
                }
                invoice.setPaid(paid);
                invoice.setTotalDue(rs.getString("totaldue"));

                invoiceDate = rs.getString("invoicedate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(invoiceDate);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                invoiceDate = sdf.format(d);
                invoice.setInvoiceDate(invoiceDate);

                paymentDate = rs.getString("paymentdate");
                if (paymentDate != null) {
                    d = new SimpleDateFormat("yyyy-MM-dd").parse(paymentDate);
                    sdf = new SimpleDateFormat("dd-MMM-yyyy");
                    paymentDate = sdf.format(d);
                } else {
                    paymentDate = "-";
                }
                invoice.setPaymentDate(paymentDate);

                data.add(invoice);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(invoice_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public boolean exists() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from invoice_new where shippingid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, shippingId);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            invoiceNo = rs.getString("invoiceno");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public boolean search() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from invoice_new where invoiceno=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, invoiceNo);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            invoiceNo = rs.getString("invoiceno");
            invoiceDate = rs.getString("invoicedate");
            Date d = new SimpleDateFormat("yyyy-MM-dd").parse(invoiceDate);
            invoiceDate = new SimpleDateFormat("dd-MMM-yyyy").format(d);
            shippingId = rs.getString("shippingid");
            onRoadTax = rs.getString("onroadtax");
            GST = rs.getString("gst");
            paid = rs.getString("paid");
            totalAmount = rs.getString("total");
            totalDue = rs.getString("totaldue");
            status = rs.getString("status");
            paymentDate = rs.getString("paymentdate");
            if (paymentDate != null) {
                d = new SimpleDateFormat("yyyy-MM-dd").parse(paymentDate);
                paymentDate = new SimpleDateFormat("dd-MMM-yyyy").format(d);
            }
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public boolean insert() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "insert into invoice_modify values(?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, invoiceNo);
        ps.setString(2, shippingId);
        ps.setString(3, invoiceDate);
        ps.setString(4, onRoadTax);
        ps.setString(5, GST);
        ps.setString(6, totalAmount);
        ps.setString(7, paid);
        ps.setString(8, totalDue);
        ps.setString(9, status);
        ps.setString(10, paymentDate);

        int rs = ps.executeUpdate();

        if (rs > 0) {
            flag = true;
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public boolean updateInvoicePayment() {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String query = "update invoice_new set paid=?,paymentdate=?,totaldue=?,status=? where shippingid=? and invoiceno=?";
        Date d = new Date();
        paymentDate = new SimpleDateFormat("dd-MMM-yyyy").format(d);

        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, paid);
            ps.setString(2, paymentDate);
            ps.setString(3, totalDue);
            int r = Integer.parseInt(totalDue);
            if (r == 0) {
                status = "paid";
            } else {
                status = "due";
            }
            ps.setString(4, status);
            ps.setString(5, shippingId);
            ps.setString(6, invoiceNo);
            int count = ps.executeUpdate();
            if (count > 0) {
                flag = true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return flag;
    }
    
    public boolean email() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select email from invoice_new i,customer_new c, vehicleHire_new v, location_new l, goodsreceipt_new g where v.orderno=g.orderno and l.shippingid=v.shippingid and c.firmid=g.firmid and v.shippingid=i.shippingid and i.invoiceno=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, invoiceNo);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            email = rs.getString("email");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }
}
