
package com.logisticBean;

import com.Dao.connDao;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHUBHAM
 */
public class vehicle_newBean {

    private String vehicleId;
    private String vehicleModel;
    private String registrationNumber;
    private String brandId;
    private String vehicleType;
    private String year;
    private String status;

    public String getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(String vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getVehicleModel() {
        return vehicleModel;
    }

    public void setVehicleModel(String vehicleModel) {
        this.vehicleModel = vehicleModel;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getBrandId() {
        return brandId;
    }

    public void setBrandId(String brandId) {
        this.brandId = brandId;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    

    public boolean addVehicle(vehicle_newBean vehicle) throws ParseException {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "insert into vehicle_new(vehiclemodel,registrationnumber,brandid,vehicletype,year,status) values(?,?,?,?,?,?)";
        
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, vehicleModel);
            ps.setString(2, registrationNumber);
            ps.setString(3, brandId);
            ps.setString(4, vehicleType);
            ps.setString(5, year);
            ps.setString(6, status);
           

            int count = ps.executeUpdate();
            if (count > 0) {
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public ArrayList showAll() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from vehicle_new";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                vehicle_newBean vehicle = new vehicle_newBean();
                vehicle.setVehicleId(rs.getString("vehicleid"));
                vehicle.setVehicleModel(rs.getString("vehiclemodel"));
                vehicle.setRegistrationNumber(rs.getString("registrationnumber"));
                vehicle.setBrandId(rs.getString("brandId"));
                
                data.add(vehicle);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(vehicle_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public boolean search() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from vehicle_new where vehicleid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, vehicleId);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            vehicleId = rs.getString("vehicleid");
            vehicleModel = rs.getString("vehiclemodel");
            registrationNumber = rs.getString("registrationnumber");
            brandId = rs.getString("brandid");
            vehicleType = rs.getString("vehicletype");
            year = rs.getString("year");
            status = rs.getString("status");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public int modify() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update vehicle_new set vehiclemodel=?,registrationnumber=?,brandid=?,vehicletype=?,year=?,status=? where vehicleid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, vehicleModel);
        ps.setString(2, registrationNumber);
        ps.setString(3, brandId);
        ps.setString(4, vehicleType);
        ps.setString(5, year);
        ps.setString(6, status);
        ps.setString(7, vehicleId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public int delete() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "delete from vehicle_new where vehicleid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, vehicleId);

        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }
    
     public ArrayList showAllUnassigned() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from vehicle_new where status='unassigned'";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                vehicle_newBean vehicle = new vehicle_newBean();
                vehicle.setVehicleId(rs.getString("vehicleid"));
                vehicle.setVehicleModel(rs.getString("vehiclemodel"));
                vehicle.setRegistrationNumber(rs.getString("registrationnumber"));
                vehicle.setBrandId(rs.getString("brandId"));
                
                data.add(vehicle);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(vehicle_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }
     
}
