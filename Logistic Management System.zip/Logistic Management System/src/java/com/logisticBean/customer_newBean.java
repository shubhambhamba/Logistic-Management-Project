/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this tcustomerlate file, choose Tools | Tcustomerlates
 * and open the tcustomerlate in the editor.
 */
package com.logisticBean;

import com.Dao.connDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHUBHAM
 */
public class customer_newBean {

    private String firmId;
    private String ownerName;
    private String firmName;
    private String email;
    private String address;
    private String contact;
    private String username;
    private String password;
    private String newPassword;
    private String imagePath;

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getFirmName() {
        return firmName;
    }

    public void setFirmName(String firmName) {
        this.firmName = firmName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirmId() {
        return firmId;
    }

    public void setFirmId(String firmId) {
        this.firmId = firmId;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean registerCustomer(customer_newBean user) {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "insert into customer_new(ownername,firmname,address,username,password,contact,email) values(?,?,?,?,?,?,?)";

        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, user.getOwnerName());
            ps.setString(2, user.getFirmName());
            ps.setString(3, user.getAddress());
            ps.setString(4, user.getUsername());
            ps.setString(5, user.getPassword());
            ps.setString(6, user.getContact());
            ps.setString(7, user.getEmail());

            int count = ps.executeUpdate();
            if (count > 0) {
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public String forgotPassword(customer_newBean user) {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "select * from customer_new where ownername=? and firmname=? and username=? and contact=?";

        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, user.getOwnerName());
            ps.setString(2, user.getFirmName());
            ps.setString(3, user.getUsername());
            ps.setString(4, user.getContact());

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("password");
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return null;
    }

    public ArrayList showAll() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from customer_new";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                customer_newBean customer = new customer_newBean();
                customer.setFirmId(rs.getString("firmid"));
                customer.setOwnerName(rs.getString("ownername"));
                customer.setFirmName(rs.getString("firmname"));
                customer.setAddress(rs.getString("address"));
                customer.setUsername(rs.getString("username"));
                customer.setPassword(rs.getString("password"));
                customer.setContact(rs.getString("contact"));
                customer.setEmail(rs.getString("email"));

                data.add(customer);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public boolean search() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from customer_new where firmid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, firmId);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            firmId = rs.getString("firmid");
            ownerName = rs.getString("ownername");
            firmName = rs.getString("firmname");
            address = rs.getString("address");
            username = rs.getString("username");
            password = rs.getString("password");
            contact = rs.getString("contact");
            email = rs.getString("email");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public int modify() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update customer_new set ownername=?,firmname=?,address=?,contact=?,username=?,password=?,email=? where firmid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, ownerName);
        ps.setString(2, firmName);
        ps.setString(3, address);
        ps.setString(4, contact);
        ps.setString(5, username);
        ps.setString(6, password);
        ps.setString(7, email);

        ps.setString(8, firmId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public int delete() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "delete from customer_new where firmid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, firmId);

        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public boolean customerLogin(customer_newBean customer) {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "select * from customer_new where username=? and password=?";

        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, customer.getUsername());
            ps.setString(2, customer.getPassword());

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                customer.setOwnerName(rs.getString("ownername"));
                customer.setFirmId(rs.getString("firmid"));
                customer.setImagePath(rs.getString("imagepath"));
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean passwordChange() {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "select * from customer_new where firmid=? and password=?";

        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, firmId);
            ps.setString(2, newPassword);

            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                String query1 = "update customer_new set password=? where firmId=? and password=?";
                PreparedStatement ps1 = connection.prepareStatement(query1);
                ps1.setString(1, newPassword);
                ps1.setString(2, firmId);
                ps1.setString(3, password);

                int count = ps1.executeUpdate();
                if (count > 0) {
                    return true;
                } else {
                    return false;
                }
            }

            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean searchById() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from customer_new c,goodsreceipt_new g where c.firmid=g.firmid and g.firmid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, firmId);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            firmId = rs.getString("firmid");
            ownerName = rs.getString("ownername");
            firmName = rs.getString("firmname");
            address = rs.getString("address");
            username = rs.getString("username");
            password = rs.getString("password");
            contact = rs.getString("contact");
            email = rs.getString("email");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public int updateImage() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update customer_new set imagepath=? where firmid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, imagePath);
        ps.setString(2, firmId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }
}
