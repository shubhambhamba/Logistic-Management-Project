/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this tdriverlate file, choose Tools | Tdriverlates
 * and open the tdriverlate in the editor.
 */
package com.logisticBean;

import com.Dao.connDao;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHUBHAM
 */
public class driver_newBean {

    private String driverId;
    private String driverName;
    private String licenseNumber;
    private String username;
    private String password;
    private String address;
    private String contact;
    private String dob;
    private String doj;
    private String status;
    private String newPassword;
    private String imagePath;
    
    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getDoj() {
        return doj;
    }

    public void setDoj(String doj) {
        this.doj = doj;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    
    public boolean addDriver(driver_newBean driver) throws ParseException {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "insert into driver_new(drivername,licensenumber,username,password,address,contact,dob,doj,status) values(?,?,?,?,?,?,?,?,?)";
        Date d = new SimpleDateFormat("MM/dd/yyyy").parse(dob);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
        dob = sdf.format(d);
        d = new SimpleDateFormat("MM/dd/yyyy").parse(doj);
        doj = sdf.format(d);
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, driverName);
            ps.setString(2, licenseNumber);
            ps.setString(3, username);
            ps.setString(4, password);
            ps.setString(5, address);
            ps.setString(6, contact);
            ps.setString(7, dob);
            ps.setString(8, doj);
             ps.setString(9, "unassigned");
             
            int count = ps.executeUpdate();
            if (count > 0) {
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public ArrayList showAll() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from driver_new";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                driver_newBean driver = new driver_newBean();
                driver.setDriverId(rs.getString("driverid"));
                driver.setDriverName(rs.getString("drivername"));
                driver.setContact(rs.getString("contact"));
                driver.setUsername(rs.getString("username"));
                
                data.add(driver);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(driver_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public boolean search() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from driver_new where driverid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, driverId);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            driverId = rs.getString("driverid");
            driverName = rs.getString("drivername");
            address = rs.getString("address");
            licenseNumber = rs.getString("licenseNumber");
            dob = rs.getString("dob");
            contact = rs.getString("contact");
            username = rs.getString("username");
            password = rs.getString("password");
            doj = rs.getString("doj");
            status=rs.getString("status");
            Date d = new SimpleDateFormat("yyyy-MM-dd").parse(dob);
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            dob = sdf.format(d);
            d = new SimpleDateFormat("yyyy-MM-dd").parse(doj);
            doj = sdf.format(d);
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public int modify() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update driver_new set drivername=?,address=?,licensenumber=?,dob=?,contact=?,username=?,password=?,doj=? where driverid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, driverName);
        ps.setString(2, address);
        ps.setString(3, licenseNumber);
        Date d = new SimpleDateFormat("MM/dd/yyyy").parse(dob);
           dob = new SimpleDateFormat("dd-MMM-yyyy").format(d);
        ps.setString(4, dob);
        ps.setString(5, contact);
        ps.setString(6, username);
        ps.setString(7, password);
        Date d1 = new SimpleDateFormat("MM/dd/yyyy").parse(doj);
           doj = new SimpleDateFormat("dd-MMM-yyyy").format(d);
        ps.setString(8, doj);
        ps.setString(9, driverId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public int delete() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "delete from driver_new where driverid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, driverId);

        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public boolean driverLogin(driver_newBean driver) {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "select * from driver_new where username=? and password=?";

        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, driver.getUsername());
            ps.setString(2, driver.getPassword());

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                driver.setDriverName(rs.getString("drivername"));
                driver.setDriverId(rs.getString("driverid"));
                driver.setImagePath(rs.getString("imagepath"));
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean passwordChange() {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "select * from driver_new where driverid=? and password=?";

        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, driverId);
            ps.setString(2, newPassword);
            
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                String query1 = "update driver_new set password=? where driverid=? and password=?";
                PreparedStatement ps1 = connection.prepareStatement(query1);
                ps1.setString(1, newPassword);
                ps1.setString(2, driverId);
                ps1.setString(3, password);

                int count = ps1.executeUpdate();
                if (count > 0) {
                    return true;
                } else {
                    return false;
                }
            }

            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public ArrayList showAllUnassigned() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from driver_new where status='unassigned'";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                driver_newBean driver = new driver_newBean();
                driver.setDriverId(rs.getString("driverid"));
                driver.setDriverName(rs.getString("drivername"));
                driver.setContact(rs.getString("contact"));
                driver.setUsername(rs.getString("username"));
                
                data.add(driver);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(driver_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }
    
    public int updateImage() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update driver_new set imagepath=? where driverid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, imagePath);
        ps.setString(2, driverId);
        count = ps.executeUpdate();
        
        ps.close();
        con.closeConnection();

        return count;
    }

}
