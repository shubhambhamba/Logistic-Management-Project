/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.logisticBean;

import com.Dao.connDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHUBHAM
 */
public class vehicleHire_newBean {

    private String shippingId;
    private String orderNo;
    private String vehicleId;
    private String driverId;
    private String shipmentDate;
    private String firmName;
    private String amount;

    public String getFirmName() {
        return firmName;
    }

    public void setFirmName(String firmName) {
        this.firmName = firmName;
    }

    public String getShippingId() {
        return shippingId;
    }

    public void setShippingId(String shippingId) {
        this.shippingId = shippingId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(String vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public String getShipmentDate() {
        return shipmentDate;
    }

    public void setShipmentDate(String shipmentDate) {
        this.shipmentDate = shipmentDate;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
    
    

    public boolean addShipment(vehicleHire_newBean vehicleHire) throws ParseException, Exception {
        connDao con = new connDao();
        Connection connection = con.getConnection();

        String query = "insert into vehiclehire_new(orderno, vehicleid, driverid, shipmentdate) values(?,?,?,?)";
        Date d = new Date();

        shipmentDate = new SimpleDateFormat("dd-MMM-yyyy").format(d);
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, orderNo);

            ps.setString(2, vehicleId);
            ps.setString(3, driverId);
            ps.setString(4, shipmentDate);

            int count = ps.executeUpdate();
            if (count > 0) {
                setVehicleAssignStatus();
                setAssignDriverStatus();
                setShippedOrderStatus();
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public ArrayList showAll() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from vehiclehire_new vh, driver_new d, goodsreceipt_new g, vehicle_new v where (g.status='dispatched' or g.status='shipped') and vh.orderno=g.orderno and d.driverid=vh.driverid and v.vehicleid=vh.vehicleid and d.status='assigned' and v.status='assigned'";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                vehicleHire_newBean vehicle1 = new vehicleHire_newBean();
                vehicle1.setOrderNo(rs.getString("orderno"));
                vehicle1.setDriverId(rs.getString("driverid"));
                vehicle1.setVehicleId(rs.getString("vehicleid"));
                vehicle1.setShippingId(rs.getString("shippingid"));
                shipmentDate = rs.getString("shipmentdate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(shipmentDate);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                shipmentDate = sdf.format(d);

                vehicle1.setShipmentDate(shipmentDate);
                data.add(vehicle1);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(vehicleHire_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public ArrayList showAllModify() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from vehiclehire_modify where shippingid=?";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1, shippingId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                vehicleHire_newBean vehicle1 = new vehicleHire_newBean();
                vehicle1.setOrderNo(rs.getString("orderno"));
                vehicle1.setDriverId(rs.getString("driverid"));
                vehicle1.setVehicleId(rs.getString("vehicleid"));
                vehicle1.setShippingId(rs.getString("shippingid"));
                shipmentDate = rs.getString("shipmentdate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(shipmentDate);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                shipmentDate = sdf.format(d);

                vehicle1.setShipmentDate(shipmentDate);
                data.add(vehicle1);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(vehicleHire_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public boolean exists() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from vehiclehire_new where driverid=? and shipmentdate=? and vehicleid=? and orderno=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, driverId);
        ps.setString(2, shipmentDate);
        ps.setString(3, vehicleId);
        ps.setString(4, orderNo);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            shippingId = rs.getString("shippingid");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public int setVehicleAssignStatus() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update vehicle_new set status=? where vehicleid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, "assigned");
        ps.setString(2, vehicleId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public int setAssignDriverStatus() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update driver_new set status=? where driverid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, "assigned");
        ps.setString(2, driverId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public int setVehicleUnassignStatus() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update vehicle_new set status=? where vehicleid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, "unassigned");
        ps.setString(2, vehicleId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public int setUnassignDriverStatus() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update driver_new set status=? where driverid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, "unassigned");
        ps.setString(2, driverId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public int setShippedOrderStatus() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update goodsreceipt_new set status=? where orderno=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, "shipped");
        ps.setString(2, orderNo);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public boolean search() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from vehiclehire_new where shippingid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, shippingId);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            shippingId = rs.getString("shippingid");
            orderNo = rs.getString("orderno");
            driverId = rs.getString("driverid");
            vehicleId = rs.getString("vehicleid");
            shipmentDate = rs.getString("shipmentdate");
            Date d = new SimpleDateFormat("yyyy-MM-dd").parse(shipmentDate);
            shipmentDate = new SimpleDateFormat("dd-MMM-yyyy").format(d);
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    
    public boolean searchFirmName() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select firmname from location_new l,vehiclehire_new v,goodsreceipt_new g,customer_new c where v.shippingid=? and v.shippingid=l.shippingid and g.firmid=c.firmid and g.orderno=v.orderno and g.status='invoice'";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, shippingId);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            firmName = rs.getString("firmName");

        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public int modify() throws Exception {

        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();
        Date d = new Date();

        shipmentDate = new SimpleDateFormat("dd-MMM-yyyy").format(d);
        String sql = "update vehiclehire_new set orderno=?,driverid=?,vehicleid=?,shipmentDate=? where shippingid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, orderNo);
        ps.setString(2, driverId);
        ps.setString(3, vehicleId);
        ps.setString(4, shipmentDate);
        ps.setString(5, shippingId);
        count = ps.executeUpdate();
        if (count > 0) {
            setAssignDriverStatus();
            setVehicleAssignStatus();
        }
        ps.close();
        con.closeConnection();

        return count;
    }

    public boolean insert() throws ParseException, Exception {
        connDao con = new connDao();
        Connection connection = con.getConnection();

        String query = "insert into vehiclehire_modify(shippingid,orderno, vehicleid, driverid, shipmentdate) values(?,?,?,?,?)";
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, shippingId);
            ps.setString(2, orderNo);
            ps.setString(3, vehicleId);
            ps.setString(4, driverId);
            ps.setString(5, shipmentDate);

            int count = ps.executeUpdate();
            if (count > 0) {
                setVehicleUnassignStatus();
                setUnassignDriverStatus();
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public ArrayList showAllDispatched() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from vehiclehire_new v,goodsreceipt_new g where v.orderno=g.orderno and v.driverid=? and g.status='shipped'";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1, driverId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                vehicleHire_newBean vehicle1 = new vehicleHire_newBean();
                vehicle1.setOrderNo(rs.getString("orderno"));
                vehicle1.setDriverId(rs.getString("driverid"));
                vehicle1.setVehicleId(rs.getString("vehicleid"));
                vehicle1.setShippingId(rs.getString("shippingid"));
                shipmentDate = rs.getString("shipmentdate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(shipmentDate);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                shipmentDate = sdf.format(d);

                vehicle1.setShipmentDate(shipmentDate);
                data.add(vehicle1);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(vehicleHire_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }
    
    public ArrayList ShippingIdDelivered() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select v.shippingid as shippingid from location_new l,vehiclehire_new v,goodsreceipt_new g,customer_new c where v.shippingid=l.shippingid and g.firmid=c.firmid and g.orderno=v.orderno and g.status='delivered'";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                vehicleHire_newBean vehicle1 = new vehicleHire_newBean();
                
                vehicle1.setShippingId(rs.getString("shippingid"));
                
                data.add(vehicle1);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(vehicleHire_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

       public boolean searchAmount() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select amountpay from location_new l,vehiclehire_new v,goodsreceipt_new g,customer_new c where v.shippingid=? and v.shippingid=l.shippingid and g.firmid=c.firmid and g.orderno=v.orderno and g.status='delivered'";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, shippingId);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            amount = rs.getString("amountpay");

        }

        ps.close();
        con.closeConnection();

        return flag;
    }
}
