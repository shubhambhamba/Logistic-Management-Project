package com.logisticBean;

import com.Dao.connDao;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHUBHAM
 */
public class goodsReceipt_newBean {

    private String orderId;
    private String firmId;

    private String orderDate;
    private String sourceCityId;
    private String destinationCityId;
    private String package1;
    private String packageDescription;
    private String empId;
    private String custId;
    private String actualWeight;
    private String chargedWeight;
    private String actualRate;
    private String chargedRate;
    private String amountPay;
    private String paymentMode;
    private String status;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getFirmId() {
        return firmId;
    }

    public void setFirmId(String firmId) {
        this.firmId = firmId;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getSourceCityId() {
        return sourceCityId;
    }

    public void setSourceCityId(String sourceCityId) {
        this.sourceCityId = sourceCityId;
    }

    public String getDestinationCityId() {
        return destinationCityId;
    }

    public void setDestinationCityId(String destinationCityId) {
        this.destinationCityId = destinationCityId;
    }

    public String getPackage1() {
        return package1;
    }

    public void setPackage1(String package1) {
        this.package1 = package1;
    }

    public String getPackageDescription() {
        return packageDescription;
    }

    public void setPackageDescription(String packageDescription) {
        this.packageDescription = packageDescription;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getActualWeight() {
        return actualWeight;
    }

    public void setActualWeight(String actualWeight) {
        this.actualWeight = actualWeight;
    }

    public String getChargedWeight() {
        return chargedWeight;
    }

    public void setChargedWeight(String chargedWeight) {
        this.chargedWeight = chargedWeight;
    }

    public String getActualRate() {
        return actualRate;
    }

    public void setActualRate(String actualRate) {
        this.actualRate = actualRate;
    }

    public String getChargedRate() {
        return chargedRate;
    }

    public void setChargedRate(String chargedRate) {
        this.chargedRate = chargedRate;
    }

    public String getAmountPay() {
        return amountPay;
    }

    public void setAmountPay(String amountPay) {
        this.amountPay = amountPay;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean addOrder(goodsReceipt_newBean order) throws ParseException {
        connDao con = new connDao();
        Connection connection = con.getConnection();

        String query = "insert into goodsreceipt_new(firmid,orderdate,sourcecityid,destinationcityid,package,packagedescription,actualweight,chargedweight,actualrate,chargedrate,amountpay,paymentmode,status,empid,custid) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        Date d = new Date();

        orderDate = new SimpleDateFormat("dd-MMM-yyyy").format(d);
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, firmId);

            ps.setString(2, orderDate);
            ps.setString(3, sourceCityId);
            ps.setString(4, destinationCityId);
            ps.setString(5, package1);
            ps.setString(6, packageDescription);
            ps.setString(7, actualWeight);
            ps.setString(8, chargedWeight);
            ps.setString(9, actualRate);
            ps.setString(10, chargedRate);
            ps.setString(11, amountPay);
            ps.setString(12, paymentMode);
            ps.setString(13, "pending");
            ps.setString(14, empId);
            ps.setString(15, custId);

            int count = ps.executeUpdate();
            if (count > 0) {
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public boolean addOrderCustomer(goodsReceipt_newBean order) throws ParseException {
        connDao con = new connDao();
        Connection connection = con.getConnection();

        String query = "insert into goodsreceipt_new(firmid,orderdate,sourcecityid,destinationcityid,package,packagedescription,actualweight,chargedweight,actualrate,chargedrate,amountpay,paymentmode,status,empid,custid) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        Date d = new Date();

        orderDate = new SimpleDateFormat("dd-MMM-yyyy").format(d);
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, firmId);
            ps.setString(2, orderDate);
            ps.setString(3, sourceCityId);
            ps.setString(4, destinationCityId);
            ps.setString(5, package1);
            ps.setString(6, packageDescription);
            ps.setString(7, actualWeight);
            ps.setString(8, chargedWeight);
            ps.setString(9, actualRate);
            ps.setString(10, chargedRate);
            ps.setString(11, amountPay);
            ps.setString(12, paymentMode);
            ps.setString(13, "booked");
            ps.setString(14, empId);
            ps.setString(15, custId);

            int count = ps.executeUpdate();
            if (count > 0) {
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public ArrayList showAll() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from goodsreceipt_new";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                goodsReceipt_newBean order = new goodsReceipt_newBean();
                order.setOrderId(rs.getString("orderno"));
                order.setFirmId(rs.getString("firmid"));
                order.setSourceCityId(rs.getString("sourcecityid"));
                order.setDestinationCityId(rs.getString("destinationcityid"));
                orderDate = rs.getString("orderdate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(orderDate);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                orderDate = sdf.format(d);

                order.setOrderDate(orderDate);
                order.setPackage1(rs.getString("package"));
                order.setPackageDescription(rs.getString("packagedescription"));
                order.setActualWeight(rs.getString("actualweight"));
                order.setChargedWeight(rs.getString("chargedweight"));
                order.setActualRate(rs.getString("actualrate"));
                order.setChargedRate(rs.getString("chargedrate"));
                order.setAmountPay(rs.getString("amountpay"));
                order.setPaymentMode(rs.getString("paymentmode"));
                order.setStatus(rs.getString("status"));
                order.setEmpId(rs.getString("empid"));
                order.setCustId(rs.getString("custid"));
                data.add(order);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(goodsReceipt_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public ArrayList showAllFirm() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from goodsreceipt_new where firmid=?";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1, firmId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                goodsReceipt_newBean order = new goodsReceipt_newBean();
                order.setOrderId(rs.getString("orderno"));
                order.setFirmId(rs.getString("firmid"));
                order.setSourceCityId(rs.getString("sourcecityid"));
                order.setDestinationCityId(rs.getString("destinationcityid"));
                orderDate = rs.getString("orderdate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(orderDate);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                orderDate = sdf.format(d);

                order.setOrderDate(orderDate);
                order.setPackage1(rs.getString("package"));
                order.setPackageDescription(rs.getString("packagedescription"));
                order.setActualWeight(rs.getString("actualweight"));
                order.setChargedWeight(rs.getString("chargedweight"));
                order.setActualRate(rs.getString("actualrate"));
                order.setChargedRate(rs.getString("chargedrate"));
                order.setAmountPay(rs.getString("amountpay"));
                order.setPaymentMode(rs.getString("paymentmode"));
                order.setStatus(rs.getString("status"));
                order.setEmpId(rs.getString("empid"));
                order.setCustId(rs.getString("custid"));
                data.add(order);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(goodsReceipt_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public boolean search() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from goodsreceipt_new where orderno=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, orderId);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            orderId = rs.getString("orderno");
            firmId = rs.getString("firmid");
            orderDate = rs.getString("orderdate");
            Date d = new SimpleDateFormat("yyyy-MM-dd").parse(orderDate);
            orderDate = new SimpleDateFormat("MM/dd/yyyy").format(d);
            sourceCityId = rs.getString("sourcecityid");
            destinationCityId = rs.getString("destinationcityid");
            package1 = rs.getString("package");
            packageDescription = rs.getString("packagedescription");
            actualWeight = rs.getString("actualweight");
            chargedWeight = rs.getString("chargedweight");
            actualRate = rs.getString("actualrate");
            chargedRate = rs.getString("chargedrate");
            amountPay = rs.getString("amountpay");
            paymentMode = rs.getString("paymentmode");
            status = rs.getString("status");
            empId = rs.getString("empid");
            custId = rs.getString("custid");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public int modify() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update goodsreceipt_new set firmid=?,sourcecityid=?,destinationcityid=?,package=?,packagedescription=?,actualweight=?,chargedweight=?,actualrate=?,chargedrate=?,amountpay=?,paymentmode=?,status=? where orderno=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, firmId);
        ps.setString(2, sourceCityId);
        ps.setString(3, destinationCityId);
        ps.setString(4, package1);
        ps.setString(5, packageDescription);
        ps.setString(6, actualWeight);
        ps.setString(7, chargedWeight);
        ps.setString(8, actualRate);
        ps.setString(9, chargedRate);
        ps.setString(10, amountPay);
        ps.setString(11, paymentMode);
        ps.setString(12, "pending");
        
        ps.setString(13, orderId);
        
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public int delete() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "delete from goodsreceipt_new where orderno=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, orderId);

        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public boolean exists() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from goodsreceipt_new where firmid=? and orderdate=? and sourcecityid=? and destinationcityid=? and package=? and packagedescription=? and actualweight=? and chargedweight=? and actualrate=? and chargedrate=? and amountpay=? and paymentmode=? and status=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, firmId);
        ps.setString(2, orderDate);
        ps.setString(3, sourceCityId);
        ps.setString(4, destinationCityId);
        ps.setString(5, package1);
        ps.setString(6, packageDescription);
        ps.setString(7, actualWeight);
        ps.setString(8, chargedWeight);
        ps.setString(9, actualRate);
        ps.setString(10, chargedRate);
        ps.setString(11, amountPay);
        ps.setString(12, paymentMode);
        ps.setString(13, "pending");

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            orderId = rs.getString("orderno");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public boolean exist() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from goodsreceipt_new where firmid=? and orderdate=? and sourcecityid=? and destinationcityid=? and package=? and packagedescription=? and actualweight=? and chargedweight=? and actualrate=? and chargedrate=? and amountpay=? and paymentmode=? and status=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, firmId);
        ps.setString(2, orderDate);
        ps.setString(3, sourceCityId);
        ps.setString(4, destinationCityId);
        ps.setString(5, package1);
        ps.setString(6, packageDescription);
        ps.setString(7, actualWeight);
        ps.setString(8, chargedWeight);
        ps.setString(9, actualRate);
        ps.setString(10, chargedRate);
        ps.setString(11, amountPay);
        ps.setString(12, paymentMode);
        ps.setString(13, "booked");

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            orderId = rs.getString("orderno");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public boolean searchById() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from employee_new e,goodsreceipt_new g where e.empid=g.empid and g.empid is not null and g.custid is null and g.empid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, empId);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public ArrayList showAllShipped() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from goodsreceipt_new where status='pending'";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                goodsReceipt_newBean order = new goodsReceipt_newBean();
                order.setOrderId(rs.getString("orderno"));
                order.setFirmId(rs.getString("firmid"));
                order.setSourceCityId(rs.getString("sourcecityid"));
                order.setDestinationCityId(rs.getString("destinationcityid"));
                orderDate = rs.getString("orderdate");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(orderDate);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                orderDate = sdf.format(d);

                order.setOrderDate(orderDate);
                order.setPackage1(rs.getString("package"));
                order.setPackageDescription(rs.getString("packagedescription"));
                order.setActualWeight(rs.getString("actualweight"));
                order.setChargedWeight(rs.getString("chargedweight"));
                order.setActualRate(rs.getString("actualrate"));
                order.setChargedRate(rs.getString("chargedrate"));
                order.setAmountPay(rs.getString("amountpay"));
                order.setPaymentMode(rs.getString("paymentmode"));
                order.setStatus(rs.getString("status"));
                order.setEmpId(rs.getString("empid"));
                order.setCustId(rs.getString("custid"));
                data.add(order);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(goodsReceipt_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

}
