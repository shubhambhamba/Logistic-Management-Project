/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.logisticBean;

import com.Dao.connDao;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHUBHAM
 */
public class employee_newBean {

    private String empid;
    private String empname;
    private String address;
    private String gender;
    private String dob;
    private String maritalStatus;
    private String contact;
    private String username;
    private String password;
    private String newPassword;
    private String email;
    private String doj;
    private String imagePath;

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDoj() {
        return doj;
    }

    public void setDoj(String doj) {
        this.doj = doj;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public boolean addEmployee(employee_newBean employee) throws ParseException {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "insert into employee_new(empname,address,gender,dob,maritalstatus,contact,username,password,email,doj) values(?,?,?,?,?,?,?,?,?,?)";
        Date d = new SimpleDateFormat("MM/dd/yyyy").parse(dob);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
        dob = sdf.format(d);
        d = new SimpleDateFormat("MM/dd/yyyy").parse(doj);
        doj = sdf.format(d);
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, empname);
            ps.setString(2, address);
            ps.setString(3, gender);
            ps.setString(4, dob);
            ps.setString(5, maritalStatus);
            ps.setString(6, contact);
            ps.setString(7, username);
            ps.setString(8, password);
            ps.setString(9, email);
            ps.setString(10, doj);

            int count = ps.executeUpdate();
            if (count > 0) {
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public ArrayList showAll() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from employee_new";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                employee_newBean emp = new employee_newBean();
                emp.setEmpid(rs.getString("empid"));
                emp.setEmpname(rs.getString("empname"));
                emp.setContact(rs.getString("contact"));
                emp.setUsername(rs.getString("username"));
                dob = rs.getString("dob");
                Date d = new SimpleDateFormat("yyyy-MM-dd").parse(dob);
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                dob = sdf.format(d);
                emp.setDob(dob);
                data.add(emp);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(employee_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public boolean search() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from employee_new where empid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, empid);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            empid = rs.getString("empid");
            empname = rs.getString("empname");
            address = rs.getString("address");
            gender = rs.getString("gender");
            dob = rs.getString("dob");
            maritalStatus = rs.getString("maritalStatus");
            contact = rs.getString("contact");
            username = rs.getString("username");
            password = rs.getString("password");
            email = rs.getString("email");
            doj = rs.getString("doj");
            Date d = new SimpleDateFormat("yyyy-MM-dd").parse(dob);
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            dob = sdf.format(d);
            d = new SimpleDateFormat("yyyy-MM-dd").parse(doj);
            doj = sdf.format(d);
        }

        ps.close();
        con.closeConnection();

        return flag;
    }

    public int modify() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update employee_new set empname=?,address=?,gender=?,dob=?,maritalstatus=?,contact=?,username=?,password=?,email=?,doj=? where empid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, empname);
        ps.setString(2, address);
        ps.setString(3, gender);
        Date d = new SimpleDateFormat("MM/dd/yyyy").parse(dob);
           dob = new SimpleDateFormat("dd-MMM-yyyy").format(d);
        ps.setString(4, dob);
        
        ps.setString(5, maritalStatus);
        ps.setString(6, contact);
        ps.setString(7, username);
        ps.setString(8, password);
        ps.setString(9, email);
        Date d1 = new SimpleDateFormat("MM/dd/yyyy").parse(doj);
           doj = new SimpleDateFormat("dd-MM-yyyy").format(d);
        ps.setString(10, doj);
        ps.setString(11, empid);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public int delete() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "delete from employee_new where empid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, empid);

        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public boolean employeeLogin(employee_newBean employee) {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "select * from employee_new where username=? and password=?";

        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, employee.getUsername());
            ps.setString(2, employee.getPassword());

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                employee.setEmpname(rs.getString("empname"));
                employee.setEmpid(rs.getString("empid"));
                employee.setImagePath(rs.getString("imagepath"));
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean passwordChange() {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "select * from employee_new where empid=? and password=?";

        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, empid);
            ps.setString(2, newPassword);

            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                String query1 = "update employee_new set password=? where empid=? and password=?";
                PreparedStatement ps1 = connection.prepareStatement(query1);
                ps1.setString(1, newPassword);
                ps1.setString(2, empid);
                ps1.setString(3, password);

                int count = ps1.executeUpdate();
                if (count > 0) {
                    return true;
                } else {
                    return false;
                }
            }

            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public int updateImage() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update employee_new set imagepath=? where empid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, imagePath);
        ps.setString(2, empid);
        count = ps.executeUpdate();
        
        ps.close();
        con.closeConnection();

        return count;
    }
}

