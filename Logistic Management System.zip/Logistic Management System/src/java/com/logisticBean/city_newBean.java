
package com.logisticBean;

import com.Dao.connDao;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHUBHAM
 */
public class city_newBean {

    private String cityId;
    private String cityName;

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
    
    public boolean addCity(city_newBean city) throws ParseException {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "insert into city_new(cityname) values(?)";
        
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, cityName);

            int count = ps.executeUpdate();
            if (count > 0) {
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public ArrayList showAll() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from city_new";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                city_newBean city = new city_newBean();
                city.setCityId(rs.getString("cityid"));
                city.setCityName(rs.getString("cityname"));
                
                data.add(city);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(city_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public boolean search() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from city_new where cityid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, cityId);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            cityId = rs.getString("cityid");
            cityName = rs.getString("cityname");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }
    

    public int modify() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update city_new set cityname=? where cityid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, cityName);
         ps.setString(2, cityId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public int delete() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "delete from city_new where cityid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, cityId);

        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }
}
