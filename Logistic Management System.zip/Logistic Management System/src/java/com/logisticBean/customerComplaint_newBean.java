/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.logisticBean;

import com.Dao.connDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHUBHAM
 */
public class customerComplaint_newBean {
    
    private String firmId;
    private String complaintId;
    private String complaint;

    public String getFirmId() {
        return firmId;
    }

    public void setFirmId(String firmId) {
        this.firmId = firmId;
    }

    
    public String getComplaintId() {
        return complaintId;
    }

    public void setComplaintId(String complaintId) {
        this.complaintId = complaintId;
    }

    public String getComplaint() {
        return complaint;
    }

    public void setComplaint(String complaint) {
        this.complaint = complaint;
    }
    
    public boolean addComplaint() throws ParseException {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "insert into customercomplaint_new(complaint,firmid) values(?,?)";
        
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, complaint);
            ps.setString(2, firmId);

            int count = ps.executeUpdate();
            if (count > 0) {
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }
    
    public ArrayList showAll() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from customercomplaint_new";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                customerComplaint_newBean vehicleIssue = new customerComplaint_newBean();
                vehicleIssue.setComplaintId(rs.getString("complaintid"));
                vehicleIssue.setComplaint(rs.getString("complaint"));
                vehicleIssue.setFirmId(rs.getString("firmid"));
                
                
                data.add(vehicleIssue);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(customerComplaint_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }
}
