
package com.logisticBean;

import com.Dao.connDao;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHUBHAM
 */
public class brand_newBean {

    private String brandId;
    private String brandName;

    public String getBrandId() {
        return brandId;
    }

    public void setBrandId(String brandId) {
        this.brandId = brandId;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }
    
    public boolean addBrand(brand_newBean brand) throws ParseException {
        connDao con = new connDao();
        Connection connection = con.getConnection();
        String query = "insert into brand_new(brandname) values(?)";
        
        try {
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, brandName);

            int count = ps.executeUpdate();
            if (count > 0) {
                return true;
            }
            con.closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public ArrayList showAll() throws ParseException {
        ArrayList data = new ArrayList();

        connDao con = new connDao();
        Connection connection = con.getConnection();
        String sql = "select * from brand_new";
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                brand_newBean brand = new brand_newBean();
                brand.setBrandId(rs.getString("brandid"));
                brand.setBrandName(rs.getString("brandname"));
                
                data.add(brand);
            }

            ps.close();
            con.closeConnection();

        } catch (SQLException ex) {
            Logger.getLogger(brand_newBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public boolean search() throws Exception {
        boolean flag = false;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "select * from brand_new where brandid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, brandId);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            flag = true;
            brandId = rs.getString("brandid");
            brandName = rs.getString("brandname");
        }

        ps.close();
        con.closeConnection();

        return flag;
    }
    

    public int modify() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "update brand_new set brandname=? where brandid=?";
        PreparedStatement ps = connection.prepareStatement(sql);

        ps.setString(1, brandName);
         ps.setString(2, brandId);
        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }

    public int delete() throws Exception {
        int count = 0;

        connDao con = new connDao();
        Connection connection = con.getConnection();

        String sql = "delete from brand_new where brandid=?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, brandId);

        count = ps.executeUpdate();

        ps.close();
        con.closeConnection();

        return count;
    }
}
