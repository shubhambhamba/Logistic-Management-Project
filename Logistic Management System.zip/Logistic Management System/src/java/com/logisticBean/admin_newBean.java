/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.logisticBean;

import com.Dao.connDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHUBHAM
 */
public class admin_newBean {
    private String username;
    private String password;
    private String newPassword;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
    
   
    public boolean adminLogin(admin_newBean admin ){
        connDao con=new connDao();
        Connection connection=con.getConnection();
        String query="select * from admin_new where username=? and password=?";
        
       try {
           PreparedStatement ps = connection.prepareStatement(query);
           ps.setString(1, admin.getUsername());
           ps.setString(2, admin.getPassword());
           
           ResultSet rs=ps.executeQuery();
           if(rs.next())
               return true;
           con.closeConnection();
       } catch (SQLException ex) {
           Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
       }
        return false;
    }
    
    public boolean passwordChange(){
        connDao con=new connDao();
        Connection connection=con.getConnection();
        String query="select * from admin_new where username=? and password=?";
        
       try {
           PreparedStatement ps = connection.prepareStatement(query);
           ps.setString(1, username);
           ps.setString(2, newPassword);
           
           ResultSet rs=ps.executeQuery();
           if(!rs.next())
           {
               String query1="update admin_new set password=? where username=? and password=?";
               PreparedStatement ps1 = connection.prepareStatement(query1);
               ps1.setString(1, newPassword);
               ps1.setString(2, username);
               ps1.setString(3, password);
               
               int count=ps1.executeUpdate();
               if(count>0)
                   return true;
               else
                   return false;
           }
               
           con.closeConnection();
       } catch (SQLException ex) {
           Logger.getLogger(customer_newBean.class.getName()).log(Level.SEVERE, null, ex);
       }
        return false;
    }
}
